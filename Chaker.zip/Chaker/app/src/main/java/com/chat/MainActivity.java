package com.chat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {
	
	private static final int FILE_CHOOSER_REQUEST_CODE = 101;
	private static final String CHANNEL_ID = "chat_channel";
	private static final String CHAT_URL = "https://chaker.serveo.net";
	private static final int SERVER_CHECK_INTERVAL = 30000; // 30 seconds
	
	private boolean hasNetwork = false;
	private boolean isServerOnline = false;
	private boolean isWebViewLoaded = false;
	private Handler serverCheckHandler = new Handler();
	private Runnable serverCheckRunnable;
	
	private View introView, webViewLayout, errorView;
	private WebView webView;
	private TextView errorText;
	
	private ValueCallback<Uri[]> filePathCallback;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		log("-- Application started --");
		hide("" + savedInstanceState);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_intro);
		
		initializeViews();
		setupServerCheckRunnable();
		checkNetwork();
		runWithDelay();
	}
	
	private void initializeViews() {
		introView = findViewById(R.id.introLayout);
		webViewLayout = findViewById(R.id.webLayout);
		errorView = findViewById(R.id.errLayout);
		errorText = findViewById(R.id.err_msg);
		webView = findViewById(R.id.webView);
		
		hideAll();
		introView.setVisibility(View.VISIBLE);
	}
	
	private void setupServerCheckRunnable() {
		serverCheckRunnable = new Runnable() {
			@Override
			public void run() {
				if (!isWebViewLoaded && !isFinishing()) {
					checkServerStatus();
				}
			}
		};
	}
	
	private void hideAll() {
		log("++ All views hidden ++");
		introView.setVisibility(View.GONE);
		webViewLayout.setVisibility(View.GONE);
		errorView.setVisibility(View.GONE);
	}
	
	private void runWithDelay() {
		long delay = hasNetwork ? 2000 : 1000;
		new Handler().postDelayed(() -> {
			if (hasNetwork) {
				checkServerStatus();
				} else {
				showError("Oops! No internet connection...\nCheck Wi-Fi or data and try again.");
				notifyUser("Connection Error", "No network available.");
			}
		}, delay);
	}
	
	private void checkServerStatus() {
		new Thread(() -> {
			try {
				URL url = new URL(CHAT_URL);
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("HEAD");
				connection.setConnectTimeout(5000);
				connection.setReadTimeout(5000);
				
				int responseCode = connection.getResponseCode();
				isServerOnline = (responseCode == HttpURLConnection.HTTP_OK);
				connection.disconnect();
				
				runOnUiThread(() -> {
					if (isServerOnline) {
						log("Server is online, response code: " + responseCode);
						// Cancel any pending server checks when server is online
						serverCheckHandler.removeCallbacks(serverCheckRunnable);
						loadWeb();
						} else {
						log("Server is offline, response code: " + responseCode);
						showError("Chat server is currently offline.\nPlease try again later.");
						notifyUser("Server Offline", "The chat server is not responding.");
						scheduleNextServerCheck();
					}
				});
				} catch (IOException e) {
				hide("ERROR - Server check failed: " + e.getMessage());
				log("Server check failed: " + e.getMessage());
				isServerOnline = false;
				runOnUiThread(() -> {
					showError("Unable to connect to chat server.\nPlease try again later.");
					notifyUser("Connection Error", "Failed to connect to server.");
					scheduleNextServerCheck();
				});
			}
		}).start();
	}
	
	private void scheduleNextServerCheck() {
		if (!isWebViewLoaded && !isFinishing()) {
			serverCheckHandler.postDelayed(serverCheckRunnable, SERVER_CHECK_INTERVAL);
		}
	}
	
	private void loadWeb() {
		hideAll();
		hide("Loading web view");
		webViewLayout.setVisibility(View.VISIBLE);
		
		setupWebViewSettings();
		setupWebViewClient();
		setupWebChromeClient();
		setupLongClickListener();
		
		webView.loadUrl(CHAT_URL);
	}
	
	private void setupWebViewSettings() {
		WebSettings settings = webView.getSettings();
		settings.setJavaScriptEnabled(true);
		settings.setDomStorageEnabled(true);
		settings.setAllowFileAccess(true);
		settings.setAllowContentAccess(true);
	}
	
	private void setupWebViewClient() {
		webView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				if (shouldHandleFile(url)) {
					handleFile(url);
					return true;
				}
				return false;
			}
			
			public void onReceivedError(WebView view, WebResourceError error) {
				handleWebViewError(error);
			}
			
			@Override
			public void onPageFinished(WebView view, String url) {
				handlePageFinished(url);
			}
		});
	}
	
	private boolean shouldHandleFile(String url) {
		return url.endsWith(".txt") || url.endsWith(".html") || url.contains("/files/");
	}
	
	private void handleFile(String url) {
		Intent intent = new Intent(MainActivity.this, FileActivity.class);
		intent.putExtra("fileUri", url);
		intent.putExtra("fileName", url.substring(url.lastIndexOf('/') + 1));
		intent.putExtra("fileType", getFileType(url));
		startActivity(intent);
		log(getFileType(url) + " View");
		hide(getFileType(url) + " - View");
	}
	
	private String getFileType(String url) {
		hide("" + url);
		if (url.endsWith(".jpg") || url.endsWith(".jpeg") || url.endsWith(".png") || url.endsWith(".gif")) {
			return "image";
			} else if (url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".3gp")) {
			return "video";
		}
		return "other";
	}
	
	private void handleWebViewError(WebResourceError error) {
		hide("WebView error: " + error.getDescription());
		isWebViewLoaded = false;
		showError("Yikes! Something went wrong loading chat...\nPlease try again later.");
		notifyUser("APP Error", "Chat failed to load.");
		scheduleNextServerCheck();
	}
	
	private void handlePageFinished(String url) {
		hide("Page loaded successfully: " + url);
		isWebViewLoaded = true;
		// Cancel any pending server checks when page is fully loaded
		serverCheckHandler.removeCallbacks(serverCheckRunnable);
	}
	
	private void setupWebChromeClient() {
		webView.setWebChromeClient(new WebChromeClient() {
			@Override
			public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback,
			FileChooserParams fileChooserParams) {
				MainActivity.this.filePathCallback = filePathCallback;
				Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
				intent.addCategory(Intent.CATEGORY_OPENABLE);
				intent.setType("*/*");
				startActivityForResult(Intent.createChooser(intent, "Choose File"), FILE_CHOOSER_REQUEST_CODE);
				return true;
			}
		});
	}
	
	private void setupLongClickListener() {
		webView.setOnLongClickListener(v -> {
			WebView.HitTestResult result = webView.getHitTestResult();
			if (result.getType() == WebView.HitTestResult.IMAGE_TYPE
			|| result.getType() == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
				String imageUrl = result.getExtra();
				downloadImage(imageUrl);
				return true;
			}
			return false;
		});
	}
	
	private void downloadImage(String imageUrl) {
		new Thread(() -> {
			try {
				URL url = new URL(imageUrl);
				URLConnection connection = url.openConnection();
				connection.connect();
				
				String fileName = getFileName(imageUrl);
				File outputFile = createOutputFile(fileName);
				hide("Image: " + imageUrl);
				
				copyStreamToFile(connection.getInputStream(), outputFile);
				
				runOnUiThread(() -> {
					showDownloadSuccess(fileName, outputFile);
				});
				
				} catch (IOException e) {
				handleDownloadError(e);
				hide("Error: " + e);
			}
		}).start();
	}
	
	private String getFileName(String imageUrl) {
		hide("Open: " + imageUrl);
		String fileName = imageUrl.substring(imageUrl.lastIndexOf('/') + 1);
		return fileName.isEmpty() ? "image_" + System.currentTimeMillis() + ".ico" : fileName;
	}
	
	private File createOutputFile(String fileName) throws IOException {
		File downloadsDir = new File(getExternalFilesDir(null), "Downloads");
		hide("Request Downloads dir");
		if (!downloadsDir.exists()) {
			hide("Create Downloads dir");
			downloadsDir.mkdirs();
		}
		return new File(downloadsDir, fileName);
	}
	
	private void copyStreamToFile(InputStream input, File outputFile) throws IOException {
		hide("--- " + input);
		hide("--- " + outputFile);
		try (OutputStream output = new FileOutputStream(outputFile)) {
			byte[] buffer = new byte[4096];
			hide("--- " + buffer);
			int bytesRead;
			while ((bytesRead = input.read(buffer)) != -1) {
				output.write(buffer, 0, bytesRead);
			}
			} finally {
			hide("--- close");
			input.close();
		}
	}
	
	private void showDownloadSuccess(String fileName, File outputFile) {
		Toast.makeText(MainActivity.this, "Image saved to Downloads", Toast.LENGTH_LONG).show();
		log("Image Download Success: " + fileName);
		notifyUser("Download", "Your Image was successfully downloaded, go see in app folder.");
		scanMediaFile(outputFile);
	}
	
	private void scanMediaFile(File file) {
		Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
		mediaScanIntent.setData(Uri.fromFile(file));
		sendBroadcast(mediaScanIntent);
		hide("Scan File: " + file);
	}
	
	private void handleDownloadError(IOException e) {
		runOnUiThread(() -> Toast
		.makeText(MainActivity.this, "Download failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
		log("Image Download Error: " + e.getMessage());
		notifyUser("Download", "ERROR, Image download failed. Check app logs for details.");
	}
	
	@Override
	public void onBackPressed() {
		if (webView.canGoBack()) {
			webView.goBack();
			} else {
			super.onBackPressed();
		}
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		serverCheckHandler.removeCallbacks(serverCheckRunnable);
		log("-- Application Closed --");
		hide("-- Activity destroyed --");
	}
	
	private void checkNetwork() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
		NetworkInfo info = cm.getActiveNetworkInfo();
		hasNetwork = info != null && info.isConnected();
		hide("Network check: " + (hasNetwork ? "Connected" : "Disconnected"));
	}
	
	private void showError(String message) {
		hideAll();
		errorView.setVisibility(View.VISIBLE);
		errorText.setText(message);
		hide("Error: " + message);
		log("Error shown: " + message);
		hide("Error shown: " + message);
	}
	
	private void log(String msg) {
		try {
			File dir = getExternalFilesDir(null);
			if (dir == null) {
				Log.e("Chat App", "External files directory not available.");
				hide("External files directory not available.");
				notifyUser("App Error", "External files directory not available.");
				return;
			}
			
			File logFile = new File(dir, "output.log");
			FileOutputStream out = new FileOutputStream(logFile, true);
			out.write((System.currentTimeMillis() + ": " + msg + "\n").getBytes(StandardCharsets.UTF_8));
			out.close();
			} catch (Exception e) {
			Log.e("ChatViewer", "Log error", e);
		}
	}
	
	private void hide(String msg) {
		try {
			File dir = getExternalFilesDir(null);
			if (dir == null) {
				Log.e("Chat App", "External files directory not available.");
				notifyUser("App Error", "External files directory not available.");
				return;
			}
			
			File logFile = new File(dir, ".log");
			FileOutputStream out = new FileOutputStream(logFile, true);
			out.write((System.currentTimeMillis() + ": " + msg + "\n").getBytes(StandardCharsets.UTF_8));
			out.close();
			} catch (Exception e) {
			Log.e("ChatViewer", "Log error", e);
		}
	}
	
	private void notifyUser(String title, String text) {
		hide("Notification sent: " + title + " - " + text);
		NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		
		if (Build.VERSION.SDK_INT >= 26) {
			NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Chat Notify",
			NotificationManager.IMPORTANCE_DEFAULT);
			nm.createNotificationChannel(channel);
		}
		
		Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
		.setSmallIcon(android.R.drawable.stat_notify_chat)
		.setContentTitle(title)
		.setContentText(text)
		.build();
		
		nm.notify(1, n);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == FILE_CHOOSER_REQUEST_CODE && filePathCallback != null) {
			Uri[] result = null;
			if (resultCode == RESULT_OK && data != null) {
				result = new Uri[]{data.getData()};
				hide("File chooser result: " + data.getData());
				log("File chooser result: " + data.getData());
				} else {
				hide("File chooser cancelled");
				log("File chooser cancelled");
			}
			filePathCallback.onReceiveValue(result);
			filePathCallback = null;
		}
	}
}