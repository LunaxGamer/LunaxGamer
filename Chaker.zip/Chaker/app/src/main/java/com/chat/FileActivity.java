package com.chat;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.Toast;
import com.chat.R;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class FileActivity extends AppCompatActivity {

    private static final String TAG = "FileActivity";
    private TextView fileNameTextView;
    private ImageView imagePreview;
    private VideoView videoPreview;
    private Button backButton, downloadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file);

        // Initialize views
        fileNameTextView = findViewById(R.id.fileName);
        imagePreview = findViewById(R.id.imagePreview);
        videoPreview = findViewById(R.id.videoPreview);
        backButton = findViewById(R.id.backButton);
        downloadButton = findViewById(R.id.downloadButton);

        // Get file URI and type from the intent
        Uri fileUri = getIntent().getParcelableExtra("fileUri");
        String fileName = getIntent().getStringExtra("fileName");
        String fileType = getIntent().getStringExtra("fileType");

        // Handle the file view based on its type (image, video, other)
        if (fileUri != null) {
            displayFile(fileUri, fileName, fileType);
        }

        // Set onClick for Back button
        backButton.setOnClickListener(v -> {
            Intent backIntent = new Intent(FileActivity.this, MainActivity.class);
            startActivity(backIntent);
            finish(); // Close current activity
        });

        // Set onClick for Download button
        downloadButton.setOnClickListener(v -> {
            if (fileUri != null) {
                downloadFile(fileUri);
            }
        });
    }

    private void displayFile(Uri fileUri, String fileName, String fileType) {
        if ("image".equals(fileType)) {
            // Show image
            imagePreview.setVisibility(View.VISIBLE);
            videoPreview.setVisibility(View.GONE);
            fileNameTextView.setVisibility(View.GONE);
            imagePreview.setImageURI(fileUri);
        } else if ("video".equals(fileType)) {
            // Show video
            videoPreview.setVisibility(View.VISIBLE);
            imagePreview.setVisibility(View.GONE);
            fileNameTextView.setVisibility(View.GONE);
            videoPreview.setVideoURI(fileUri);
            videoPreview.start();
        } else {
            // Non-image/video, just show the filename
            fileNameTextView.setVisibility(View.VISIBLE);
            imagePreview.setVisibility(View.GONE);
            videoPreview.setVisibility(View.GONE);
            fileNameTextView.setText(fileName);
        }
    }

    private void downloadFile(Uri fileUri) {
        // Initiate download manager
        DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        if (downloadManager != null) {
            DownloadManager.Request request = new DownloadManager.Request(fileUri);
            request.setTitle("Downloading file...");
            request.setDescription("File is being downloaded.");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalFilesDir(this, null, new File(fileUri.getPath()).getName());

            try {
                downloadManager.enqueue(request);
                Toast.makeText(this, "Download started!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e(TAG, "Error initiating download: " + e.getMessage());
                Toast.makeText(this, "Failed to start download.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}